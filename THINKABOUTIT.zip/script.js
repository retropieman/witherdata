$("#topbar").load("common/top.htm");
$("#sidebar").load("common/side.htm");